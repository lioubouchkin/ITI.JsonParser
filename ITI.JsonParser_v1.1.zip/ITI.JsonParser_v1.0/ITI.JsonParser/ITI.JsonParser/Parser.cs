﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ITI.JsonParser
{

    public static class Parser
    {

        public static double ParseDouble( string value, ref int start, ref int count )
        {
            throw new NotImplementedException();
        }

        public static string ParseString( string value, ref int start, ref int count )
        {
            throw new NotImplementedException();
        }

        public static bool ParseBoolean( string value, ref int start, ref int count )
        {
            throw new NotImplementedException();
        }

        public static object[] ParseArray( string value, ref int start, ref int count )
        {
            throw new NotImplementedException();
        }

        public static Dictionary<String, Object> ParseObject( string value, ref int start, ref int count )
        {
            throw new NotImplementedException();
        }
    }
}
